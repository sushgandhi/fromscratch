
import streamlit as st

from salesbot_backend import process_chat_request

st.set_page_config(page_title="SalesBot", page_icon="💹")
st.title("SalesBot – Fixed Income Assistant")

with st.sidebar:
    st.header("Features")
    current_features = st.checkbox("Current features (summary & order info)", value=True)
    bond_recommender = st.checkbox("Bond recommendation (beta)", value=True)

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

for role, msg in st.session_state.chat_history:
    if role == "user":
        st.chat_message("user").markdown(msg)
    else:
        st.chat_message("assistant").markdown(msg)

if prompt := st.chat_input("Ask about trades, orders, or bond ideas..."):
    st.session_state.chat_history.append(("user", prompt))
    st.chat_message("user").markdown(prompt)

    requestData = {
        "messageBody": prompt,
        "userId": "demo_user",
        "features": {
            "current": current_features,
            "bond_recommender": bond_recommender,
        },
    }

    with st.chat_message("assistant"):
        reply = process_chat_request(requestData)
        st.markdown(reply)
        st.session_state.chat_history.append(("assistant", reply))
