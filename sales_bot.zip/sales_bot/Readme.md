## SalesBot Bond Recommendation – Design & Implementation


### Overview

We have an existing Python-based Sales Assistant Chatbot (SalesBot) that supports:

- Summarising a salesperson’s trades or book
- Showing order details

We want to add a new capability:

<b>Given a CUSIP (or a natural-language query referring to a bond), recommend similar bonds using an internal Bond Recommendation API, and present them in a sales-friendly format.</b>

Key requirements:

- Detect when a user’s query is a bond recommendation request vs other existing behaviours
- Extract CUSIPs and constraints (size, top N, time window, source) from natural language
- Call a bond recommendation API (schema given)
- Handle invalid or non-covered CUSIPs gracefully (e.g. 404)
- Return a clean, actionable answer for sales

Assumptions: 

- There are no restrictions on which sales/customer has ownership/representation of CUSIP (not in requirement)
- 

### High level Architecture

#### Components : 

**Frontend**

- Chat interface with conversational history
- Sidebar toggles:
    - Current features (summary & order info)
    - Bond recommendation

**Backend**
- Main entrypoint: process_chat_request(requestData)
- Gemini 2.5 Pro client with:
    -- Base system prompt describing all supported intents
    -- Bond add-on system prompt, conditionally added when bond feature is enabled
    -- Function/tool declaration for get_bond_recommendations

**Bond Recommendation API**

- In production: https://internal.net/sales_recommendation
- In this implementation: simulated by a hard-coded JSON dictionary keyed by CUSIP.
- Schema: match_trades, match_bids, match_portfolios, each with fields like: SourceCusip, TargetCusip, RECOMMENDATION_SCORE, RANK_SCORE, GrandParentName, Size, Coupon, Term, WAL, etc.

**Support logic**
- Regex-based CUSIP detection/validation
- Formatting of bond recommendations into concise, sales-friendly bullets

#### Flow Diagram

flowchart LR
    U[User in Streamlit] -->|types message| S[Streamlit app]
    S -->|build requestData| B[process_chat_request()]
    B -->|compose system prompts & tools| G[Gemini 2.5 Pro]

    G -->|response| D{Contains function_call?}

    D -- No --> R0[Return Gemini text\n(trade summary / order info)]
    D -- Yes & name=get_bond_recommendations --> V[Validate CUSIP via regex]

    V -- invalid --> R1[Return polite\n'invalid CUSIP' message]
    V -- valid --> A[fake_bond_api(cusip)]
    A --> F[Rank & format\nrecommendations]
    F --> R2[Return formatted\nbond recommendations]

    R0 --> S
    R1 --> S
    R2 --> S
    S -->|render chat| U


#### Intent classification & query types:

- The bot needs to handle three high-level intents:
    - TRADE_SUMMARY – e.g. “Summarise my trades in Fannie Mae last week”
    - ORDER_DETAILS – e.g. “Show status for order 12345”
    - BOND_RECOMMENDATION – e.g. “Recommend me bonds similar to 05461AE21 larger than 10mm”

<b> Do we need anything beyond a system prompt?</b>

I do not introduce a separate classifier model. Instead, I use:
- A carefully designed system prompt,
- Function calling for bond recommendation,
so that:

- Trade/Order style queries → Gemini responds directly in natural language (existing behaviour).
- Bond recommendation queries → Gemini emits a function_call for get_bond_recommendations.

This keeps architecture simple and leverages Gemini’s native intent understanding.

<b>For robustness, I still:</b>

- Use a CUSIP regex server-side to validate any cusip arguments.
- Handle invalid or missing CUSIPs gracefully.

#### Gemini 2.5 Pro – Prompts & tools

<b> >Prompt design (CoT / DSPy-style thinking)</b>

I designed the prompts with a Chain-of-Thought (CoT) mindset and in a way that would work well with a DSPy-style teleprompter if we wanted to auto-tune them later

1. Instruct the model to “think step by step”:

- First: identify business intent
- Second: identify CUSIPs (9-character alphanumeric)
- Third: extract constraints (size, top N, time window, source)
- Finally: either answer directly or call the bond tool.

2. Few shot example to "anchor" the model.

3. Tool Declaration

Single tool is exposed to Germany
```
BOND_TOOL_DECL = {
    "name": "get_bond_recommendations",
    "description": "Get recommended bonds similar to a given CUSIP",
    "parameters": {
        "type": "object",
        "properties": {
            "cusip": {"type": "string", "description": "9-character CUSIP"},
            "min_notional": {"type": "number", "description": "Minimum size in base currency"},
            "top_n": {"type": "integer", "description": "Number of recs to return"},
            "sources": {
                "type": "array",
                "items": {"type": "string", "enum": [
                    "match_trades", "match_bids", "match_portfolios"
                ]},
                "description": "Preferred recommendation buckets"
            },
            "time_window_days": {"type": "integer", "description": "Lookback window in days"},
        },
        "required": ["cusip"],
    },
}
```
### Bond recommendation logic:

I use a simple regex to detect and validate CUSIPs:
```
CUSIP_REGEX = r"\b[A-Z0-9]{9}\b"

def extract_cusip(text: str) -> Optional[str]:
    m = re.search(CUSIP_REGEX, text.upper())
    return m.group(0) if m else None

```
Fake Bond API (hard-coded JSON)
```

HARD_CODED_BOND_DATA: Dict[str, Dict[str, Any]] = {
    "05461AE21": {
        "match_trades": [
            {
                "SourceCusip": "05461AE21",
                "RECOMMENDATION_SCORE": "High",
                "RANK_SCORE": "5",
                "TargetCusip": "3133KNN76",
                "GrandParentNumber": "000001",
                "SalesPersonSOEID": "AA00001",
                "Date": "2025-11-03",
                "SalesPersonName": "Doe_John",
                "GrandParentName": "Client Alpha",
                "Size": 20000000,
                "Coupon": 3.1,
                "Term": 20,
                "WAL": 12,
            },
        ],
        "match_bids": [
            {
                "SourceCusip": "05461AE21",
                "RECOMMENDATION_SCORE": "Medium",
                "RANK_SCORE": "3",
                "TargetCusip": "3140QLYB3",
                "GrandParentNumber": "000002",
                "SalesPersonSOEID": "AA00002",
                "Date": "2025-11-04",
                "SalesPersonName": "Doe_Jane",
                "GrandParentName": "Client Beta",
                "Size": 15000000,
                "Coupon": 2.9,
                "Term": 10,
                "WAL": 5,
            }
        ],
        "match_portfolios": [
            {
                "SourceCusip": "05461AE21",
                "RECOMMENDATION_SCORE": "High",
                "RANK_SCORE": "4",
                "TargetCusip": "3198ABCD9",
                "GrandParentNumber": "000003",
                "SalesPersonSOEID": "AA00003",
                "Date": "2025-11-05",
                "SalesPersonName": "Smith_Alice",
                "GrandParentName": "Client Gamma",
                "Size": 10000000,
                "Coupon": 3.0,
                "Term": 30,
                "WAL": 18,
            }
        ],
    },
    "0FPE121AE": {
        "match_trades": [],
        "match_bids": [],
        "match_portfolios": [
            {
                "SourceCusip": "0FPE121AE",
                "RECOMMENDATION_SCORE": "Medium",
                "RANK_SCORE": "2",
                "TargetCusip": "042AFC123",
                "GrandParentNumber": "000004",
                "SalesPersonSOEID": "AA00004",
                "Date": "2025-11-02",
                "SalesPersonName": "Lee_Chris",
                "GrandParentName": "Client Delta",
                "Size": 5000000,
                "Coupon": 2.5,
                "Term": 5,
                "WAL": 4,
            }
        ],
    },
}
```

def fake_bond_api(cusip: str) -> Optional[Dict[str, Any]]:
    return HARD_CODED_BOND_DATA.get(cusip)  # None = 404/not covered

This allows:
- End-to-end behaviour without external dependency
- Easy unit tests (we can assert on known CUSIPs)
- Simulation of “404” by returning None


<b>Formatting recommendations</b>
I combine all three buckets (match_trades, match_bids, match_portfolios), rank by recommendation strength, and render a concise summary:

```
def format_bond_response(cusip: str, api_data: Optional[Dict[str, Any]], top_n: int = 5) -> str:
    if api_data is None:
        return (
            f"I couldn't find any recommendations for CUSIP {cusip}. "
            "The CUSIP might be invalid or not covered by the recommendation engine.\n"
            "Please check the CUSIP (it should be a 9-character alphanumeric code) and try again."
        )

    recs: List[Dict[str, Any]] = []
    for bucket in ["match_trades", "match_bids", "match_portfolios"]:
        for item in api_data.get(bucket, []):
            enriched = dict(item)
            enriched["_bucket"] = bucket
            recs.append(enriched)

    if not recs:
        return (
            f"There are currently no similar-bond recommendations for {cusip} "
            "in trades, bids, or client portfolios."
        )

    recs.sort(
        key=lambda r: (
            {"High": 2, "Medium": 1, "Low": 0}.get(r.get("RECOMMENDATION_SCORE", "Low"), 0),
            int(r.get("RANK_SCORE", 0)),
        ),
        reverse=True,
    )

    top = recs[:top_n]

    lines = [f"Here are some bonds similar to **{cusip}**:"]
    for i, r in enumerate(top, start=1):
        bucket_label = r["_bucket"].replace("match_", "")
        lines.append(
            f"{i}. {r['TargetCusip']} ({bucket_label}) — "
            f"Client: {r.get('GrandParentName', 'N/A')}, "
            f"Size: {r.get('Size', 'N/A'):,}, "
            f"Coupon: {r.get('Coupon', 'N/A')}%, "
            f"Term: {r.get('Term', 'N/A')}y, WAL: {r.get('WAL', 'N/A')}."
        )

    lines.append(
        "\nYou can refine this list by asking, for example, "
        "\"show only portfolio names\", \"filter to size > 20mm\" or "
        "\"only shorter than 10 years.\""
    )
    return "\n".join(lines)

```

Formatting Logic - 
I combine all three buckets (match_trades, match_bids, match_portfolios), rank by recommendation strength, and render a concise summary

```
def format_bond_response(cusip: str, api_data: Optional[Dict[str, Any]], top_n: int = 5) -> str:
    if api_data is None:
        return (
            f"I couldn't find any recommendations for CUSIP {cusip}. "
            "The CUSIP might be invalid or not covered by the recommendation engine.\n"
            "Please check the CUSIP (it should be a 9-character alphanumeric code) and try again."
        )

    recs: List[Dict[str, Any]] = []
    for bucket in ["match_trades", "match_bids", "match_portfolios"]:
        for item in api_data.get(bucket, []):
            enriched = dict(item)
            enriched["_bucket"] = bucket
            recs.append(enriched)

    if not recs:
        return (
            f"There are currently no similar-bond recommendations for {cusip} "
            "in trades, bids, or client portfolios."
        )

    recs.sort(
        key=lambda r: (
            {"High": 2, "Medium": 1, "Low": 0}.get(r.get("RECOMMENDATION_SCORE", "Low"), 0),
            int(r.get("RANK_SCORE", 0)),
        ),
        reverse=True,
    )

    top = recs[:top_n]

    lines = [f"Here are some bonds similar to **{cusip}**:"]
    for i, r in enumerate(top, start=1):
        bucket_label = r["_bucket"].replace("match_", "")
        lines.append(
            f"{i}. {r['TargetCusip']} ({bucket_label}) — "
            f"Client: {r.get('GrandParentName', 'N/A')}, "
            f"Size: {r.get('Size', 'N/A'):,}, "
            f"Coupon: {r.get('Coupon', 'N/A')}%, "
            f"Term: {r.get('Term', 'N/A')}y, WAL: {r.get('WAL', 'N/A')}."
        )

    lines.append(
        "\nYou can refine this list by asking, for example, "
        "\"show only portfolio names\", \"filter to size > 20mm\" or "
        "\"only shorter than 10 years.\""
    )
    return "\n".join(lines)
```


### Evaluation & DSPy / FiQA

- Dataset: FiQA 2018
FiQA is a public financial QA dataset with questions and answers about stocks, bonds, loans, etc.
Available on HuggingFace; commonly used for financial QA and sentiment experiments.


- How to use it ?

- Create a labelled evaluation set
- Sample a few hundred FiQA questions.
- Label each as:
   - BOND_RECOMMENDATION (bond-related, or synthetically edited to include CUSIPs)
   - TRADE/ORDER-LIKE (questions about positions/orders, where applicable)
   - OTHER_FINANCE (out of scope).

- Wrap the prompt in DSPy

- Build a DSPy module: (question) -> (intent, maybe_cusip) using Gemini as the underlying model.
- Provide the dataset as supervision: gold_intent and gold_has_cusip.
- Use DSPy’s teleprompter (e.g. BootstrapFewShot) to optimize:
- Instruction wording
- Few-shot examples inside the prompt


### Few-shot examples (for inclusion in the prompt)

If needed, I’d embed a few examples at the end of the system prompt to reinforce the three query types.
Example few-shot block:


```
Examples:

User: "Summarise my trades in 05461AE21 over the last week."
Reasoning:
- Intent: TRADE_SUMMARY.
- The user is asking about their own trading activity.
- Do NOT call get_bond_recommendations.
Assistant: [Use existing trade summary tools and reply.]

User: "Show me the status of order 123456 for my client."
Reasoning:
- Intent: ORDER_DETAILS.
- The user is referring to a specific order ID.
- Do NOT call get_bond_recommendations.
Assistant: [Use existing order details tools and reply.]

User: "Can you recommend me bonds similar to 05461AE21 larger than 10mm?"
Reasoning:
- Intent: BOND_RECOMMENDATION.
- Extract CUSIP: 05461AE21.
- Extract min_notional: 10mm → 10000000.
- Call get_bond_recommendations(cusip="05461AE21", min_notional=10000000, top_n=5).

User: "What are the top 2 bonds in clients' portfolios similar to 0FPE121AE?"
Reasoning:
- Intent: BOND_RECOMMENDATION.
- Extract CUSIP: 0FPE121AE.
- Extract top_n: 2.
- Prefer source: match_portfolios.
- Call get_bond_recommendations(cusip="0FPE121AE", top_n=2, sources=["match_portfolios"]).

User: "Where are there any bids in the past week like 042AFC123?"
Reasoning:
- Intent: BOND_RECOMMENDATION.
- Extract CUSIP: 042AFC123.
- Extract time_window_days: 7.
- Prefer source: match_bids.
- Call get_bond_recommendations(cusip="042AFC123", time_window_days=7, sources=["match_bids"]).
```
These examples both guide the model and double as documentation for reviewers.
