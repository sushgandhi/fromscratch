# salesbot_backend.py
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import requests
from google import genai
from google.genai import types


CUSIP_REGEX = r"\b[A-Z0-9]{9}\b"

client = genai.Client()  

BASE_PROMPT = """
You are SalesBot, a sales assistant for Citi's fixed-income sales people.

You must always:
1. Understand the user's intent.
2. Classify the intent as one of:
   - TRADE_SUMMARY - summarising trades / positions / book.
   - ORDER_DETAILS - asking for details about a specific order or ticket.
   - BOND_RECOMMENDATION - asking for bonds similar to a given bond or CUSIP.
3. If the intent is TRADE_SUMMARY or ORDER_DETAILS, answer directly
   using the data returned by tools or existing chat context.
4. If the intent is BOND_RECOMMENDATION, DO NOT answer directly.
   Instead, call the tool "get_bond_recommendations" with extracted arguments.

Think step by step:
- First, reason about the user's business question.
- Second, identify any CUSIPs (9-character alphanumeric identifiers like 05461AE21).
- Third, extract constraints (notional, top N, time window, source: trades/bids/portfolios).
- Finally, decide which tool to call or whether to answer directly.

If a question is not about bonds, CUSIPs, trades, or orders, politely say you only support those topics.
"""

BOND_ADDON_PROMPT = """
Bond Recommendation Add-on:

You now support bond recommendations using the tool "get_bond_recommendations".

When the user asks for bonds "similar to" a CUSIP or bond:
- Extract the primary CUSIP using a 9-character alphanumeric pattern.
- Extract:
  - min_notional (e.g. "larger than 10mm" → 10000000)
  - top_n (e.g. "top 2" → 2, default 5)
  - preferred sources:
      - "match_trades" if they mention trades or their own book
      - "match_bids" if they mention bids or recent interest
      - "match_portfolios" if they mention client portfolios
  - time_window_days if they mention a period ("past week" → 7).

Only call the tool if:
- You found at least one candidate CUSIP; OR
- You can infer a CUSIP from context given in the conversation (e.g. they already gave one).

If the bond API returns no matches or 404, explain clearly that the CUSIP is invalid or has no recommendations and ask the user for another CUSIP.
Format all final answers in a concise sales-friendly style: bullets, key numbers, and clear next actions.
"""

BOND_TOOL_DECL = {
    "name": "get_bond_recommendations",
    "description": "Get recommended bonds similar to a given CUSIP",
    "parameters": {
        "type": "object",
        "properties": {
            "cusip": {"type": "string", "description": "9-character CUSIP"},
            "min_notional": {"type": "number", "description": "Minimum size in base currency"},
            "top_n": {"type": "integer", "description": "Number of recs to return"},
            "sources": {
                "type": "array",
                "items": {"type": "string", "enum": ["match_trades", "match_bids", "match_portfolios"]},
                "description": "Preferred recommendation buckets"
            },
            "time_window_days": {"type": "integer", "description": "Lookback window in days"},
        },
        "required": ["cusip"],
    },
}
TOOLS = types.Tool(function_declarations=[BOND_TOOL_DECL])

# tools = [bond_tool_schema, trade_summary_tool_schema, order_details_tool_schema] # this would be in real code


# ------------------- Hard-coded "bond API" data -------------------

# this won't be in real code; just for simulation

HARD_CODED_BOND_DATA: Dict[str, Dict[str, Any]] = {
    "05461AE21": {
        "match_trades": [
            {
                "SourceCusip": "05461AE21",
                "RECOMMENDATION_SCORE": "High",
                "RANK_SCORE": "5",
                "TargetCusip": "3133KNN76",
                "GrandParentNumber": "000001",
                "SalesPersonSOEID": "AA00001",
                "Date": "2025-11-03",
                "SalesPersonName": "Doe_John",
                "GrandParentName": "Client Alpha",
                "Size": 20000000,
                "Coupon": 3.1,
                "Term": 20,
                "WAL": 12,
            },
        ],
        "match_bids": [
            {
                "SourceCusip": "05461AE21",
                "RECOMMENDATION_SCORE": "Medium",
                "RANK_SCORE": "3",
                "TargetCusip": "3140QLYB3",
                "GrandParentNumber": "000002",
                "SalesPersonSOEID": "AA00002",
                "Date": "2025-11-04",
                "SalesPersonName": "Doe_Jane",
                "GrandParentName": "Client Beta",
                "Size": 15000000,
                "Coupon": 2.9,
                "Term": 10,
                "WAL": 5,
            }
        ],
        "match_portfolios": [
            {
                "SourceCusip": "05461AE21",
                "RECOMMENDATION_SCORE": "High",
                "RANK_SCORE": "4",
                "TargetCusip": "3198ABCD9",
                "GrandParentNumber": "000003",
                "SalesPersonSOEID": "AA00003",
                "Date": "2025-11-05",
                "SalesPersonName": "Smith_Alice",
                "GrandParentName": "Client Gamma",
                "Size": 10000000,
                "Coupon": 3.0,
                "Term": 30,
                "WAL": 18,
            }
        ],
    },
    "0FPE121AE": {
        "match_trades": [],
        "match_bids": [],
        "match_portfolios": [
            {
                "SourceCusip": "0FPE121AE",
                "RECOMMENDATION_SCORE": "Medium",
                "RANK_SCORE": "2",
                "TargetCusip": "042AFC123",
                "GrandParentNumber": "000004",
                "SalesPersonSOEID": "AA00004",
                "Date": "2025-11-02",
                "SalesPersonName": "Lee_Chris",
                "GrandParentName": "Client Delta",
                "Size": 5000000,
                "Coupon": 2.5,
                "Term": 5,
                "WAL": 4,
            }
        ],
    },
}

def call_bond_api(cusip: str) -> dict | None:
    try:
        resp = requests.get(BOND_API, params={"cusip": cusip}, timeout=3)
        if resp.status_code == 404:
            return None  # invalid CUSIP or no data
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException:
        # in real life: log, metrics, fallback
        return {"error": "bond_api_unavailable"}


def extract_cusip(text: str) -> Optional[str]:
    m = re.search(CUSIP_REGEX, text.upper())
    return m.group(0) if m else None


def fake_bond_api(cusip: str) -> Optional[Dict[str, Any]]:
    """Simulate the BOND_API: returns data for known CUSIPs, None for 404-equivalent."""
    return HARD_CODED_BOND_DATA.get(cusip)


def format_bond_response(cusip: str, api_data: Optional[Dict[str, Any]], top_n: int = 5) -> str:
    if api_data is None:
        return (
            f"I couldn't find any recommendations for CUSIP {cusip}. "
            "The CUSIP might be invalid or not covered by the recommendation engine.\n"
            "Please check the CUSIP (it should be a 9-character alphanumeric code) and try again."
        )

    recs: List[Dict[str, Any]] = []
    for bucket in ["match_trades", "match_bids", "match_portfolios"]:
        for item in api_data.get(bucket, []):
            enriched = dict(item)
            enriched["_bucket"] = bucket
            recs.append(enriched)

    if not recs:
        return (
            f"There are currently no similar-bond recommendations for {cusip} "
            "in trades, bids, or client portfolios."
        )

    recs.sort(
        key=lambda r: (
            # Put High > Medium > Low, fall back safely
            {"High": 2, "Medium": 1, "Low": 0}.get(r.get("RECOMMENDATION_SCORE", "Low"), 0),
            int(r.get("RANK_SCORE", 0)),
        ),
        reverse=True,
    )

    top = recs[:top_n]

    lines = [f"Here are some bonds similar to **{cusip}**:"]
    for i, r in enumerate(top, start=1):
        bucket_label = r["_bucket"].replace("match_", "")
        lines.append(
            f"{i}. {r['TargetCusip']} ({bucket_label}) — "
            f"Client: {r.get('GrandParentName', 'N/A')}, "
            f"Size: {r.get('Size', 'N/A'):,}, "
            f"Coupon: {r.get('Coupon', 'N/A')}%, "
            f"Term: {r.get('Term', 'N/A')}y, WAL: {r.get('WAL', 'N/A')}."
        )

    lines.append(
        "\nYou can refine this list by asking, for example, "
        "\"show only portfolio names\", \"filter to size > 20mm\" or "
        "\"only shorter than 10 years.\""
    )
    return "\n".join(lines)


def call_gemini_with_tools(user_msg: str, bond_feature_on: bool) -> Any:
    system_parts = [BASE_PROMPT]
    if bond_feature_on:
        system_parts.append(BOND_ADDON_PROMPT)

    messages = [
        types.Content(role="system", parts=[types.Part.from_text("\n\n".join(system_parts))]),
        types.Content(role="user", parts=[types.Part.from_text(user_msg)]),
    ]

    config = types.GenerateContentConfig(
        tools=[TOOLS] if bond_feature_on else [],
        temperature=0.2,
    )

    response = client.models.generate_content(
        model="gemini-2.5-pro",
        contents=messages,
        config=config,
    )
    return response



def process_chat_request(requestData: Dict[str, Any]) -> str:
    """
    requestData has keys:
      - messageBody: str
      - userId: str
      - features: {"current": bool, "bond_recommender": bool}
    """
    user_msg = requestData["messageBody"]
    features = requestData.get("features", {})
    bond_feature_on = features.get("bond_recommender", False)

    # First pass
    response = call_gemini_with_tools(user_msg, bond_feature_on)

    # Try to see if Gemini has made a function_call in the first part
    parts = response.candidates[0].content.parts
    first_part = parts[0] if parts else None

    if (
        bond_feature_on
        and first_part is not None
        and getattr(first_part, "function_call", None) is not None
        and first_part.function_call.name == "get_bond_recommendations"
    ):
        fc = first_part.function_call
        args = dict(fc.args or {})
        cusip = args.get("cusip") or extract_cusip(user_msg or "")

        if not cusip or not re.fullmatch(CUSIP_REGEX, cusip):
            return (
                "I couldn't recognise a valid CUSIP in your request. "
                "CUSIPs are 9-character alphanumeric codes (e.g. 05461AE21).\n"
                "Please provide a valid CUSIP so I can fetch recommendations."
            )

        api_data = fake_bond_api(cusip)

        top_n = int(args.get("top_n", 5) or 5)
        reply_text = format_bond_response(cusip, api_data, top_n=top_n)
        return reply_text

    # If no function call, fall back to Gemini's natural-language answer
    return response.text
