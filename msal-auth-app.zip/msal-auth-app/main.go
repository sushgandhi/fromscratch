package main

import (
	"context"
	"crypto/rand"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"net/http"
	"os"

	"github.com/AzureAD/microsoft-authentication-library-for-go/apps/confidential"
	"github.com/gorilla/mux"
	"github.com/gorilla/sessions"
)

var (
	store = sessions.NewCookieStore([]byte("your-secret-key"))

	// Configuration - you'll need to set these environment variables
	clientID     = os.Getenv("AZURE_CLIENT_ID")
	tenantID     = os.Getenv("AZURE_TENANT_ID")
	clientSecret = os.Getenv("AZURE_CLIENT_SECRET")
	certPath     = os.Getenv("AZURE_CERT_PATH")
	certPassword = os.Getenv("AZURE_CERT_PASSWORD")
	redirectURI  = "http://localhost:8080/callback"
	scopes       = []string{"https://graph.microsoft.com/.default"}
)

type App struct {
	client confidential.Client
}

func main() {
	if clientID == "" || tenantID == "" {
		log.Fatal("Please set AZURE_CLIENT_ID and AZURE_TENANT_ID environment variables")
	}

	app, err := NewApp()
	if err != nil {
		log.Fatal("Failed to initialize app:", err)
	}

	r := mux.NewRouter()

	// Routes
	r.HandleFunc("/", app.homeHandler).Methods("GET")
	r.HandleFunc("/login", app.loginHandler).Methods("GET")
	r.HandleFunc("/callback", app.callbackHandler).Methods("GET")
	r.HandleFunc("/profile", app.profileHandler).Methods("GET")
	r.HandleFunc("/files", app.filesHandler).Methods("GET")
	r.HandleFunc("/logout", app.logoutHandler).Methods("GET")

	// Static files
	r.PathPrefix("/static/").Handler(http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	log.Println("Server starting on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", r))
}

func NewApp() (*App, error) {
	var client confidential.Client
	var err error

	if certPath != "" {
		// Certificate-based authentication
		certData, err := ioutil.ReadFile(certPath)
		if err != nil {
			return nil, fmt.Errorf("failed to read certificate: %v", err)
		}

		cert, err := tls.X509KeyPair(certData, certData)
		if err != nil {
			return nil, fmt.Errorf("failed to parse certificate: %v", err)
		}

		client, err = confidential.New(clientID, confidential.WithCertificate(cert), confidential.WithAuthority(fmt.Sprintf("https://login.microsoftonline.com/%s", tenantID)))
		if err != nil {
			return nil, fmt.Errorf("failed to create confidential client: %v", err)
		}
	} else if clientSecret != "" {
		// Client secret authentication
		cred, err := confidential.NewCredFromSecret(clientSecret)
		if err != nil {
			return nil, fmt.Errorf("failed to create credential: %v", err)
		}

		client, err = confidential.New(clientID, cred, confidential.WithAuthority(fmt.Sprintf("https://login.microsoftonline.com/%s", tenantID)))
		if err != nil {
			return nil, fmt.Errorf("failed to create confidential client: %v", err)
		}
	} else {
		return nil, fmt.Errorf("either certificate path or client secret must be provided")
	}

	return &App{client: client}, nil
}

func (app *App) homeHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")

	data := struct {
		Authenticated bool
		Username      string
	}{
		Authenticated: session.Values["authenticated"] == true,
		Username:      fmt.Sprintf("%v", session.Values["username"]),
	}

	renderTemplate(w, "templates/index.html", data)
}

func (app *App) loginHandler(w http.ResponseWriter, r *http.Request) {
	// Generate state for CSRF protection
	state := generateRandomString(32)
	session, _ := store.Get(r, "session")
	session.Values["oauth_state"] = state
	session.Save(r, w)

	authCodeOptions := []confidential.AuthCodeOption{
		confidential.WithState(state),
	}

	authURL, err := app.client.AuthCodeURL(context.Background(), redirectURI, scopes, authCodeOptions...)
	if err != nil {
		http.Error(w, "Failed to generate auth URL", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, authURL, http.StatusTemporaryRedirect)
}

func (app *App) callbackHandler(w http.ResponseWriter, r *http.Request) {
	code := r.URL.Query().Get("code")
	state := r.URL.Query().Get("state")

	if code == "" {
		http.Error(w, "No authorization code received", http.StatusBadRequest)
		return
	}

	session, _ := store.Get(r, "session")
	savedState := session.Values["oauth_state"]

	if state == "" || savedState == nil || state != savedState {
		http.Error(w, "Invalid state parameter", http.StatusBadRequest)
		return
	}

	result, err := app.client.AcquireTokenByAuthCode(context.Background(), code, redirectURI, scopes)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to acquire token: %v", err), http.StatusInternalServerError)
		return
	}

	session.Values["authenticated"] = true
	session.Values["access_token"] = result.AccessToken
	session.Values["username"] = result.Account.PreferredUsername
	session.Save(r, w)

	http.Redirect(w, r, "/profile", http.StatusTemporaryRedirect)
}

func (app *App) profileHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	if session.Values["authenticated"] != true {
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}

	accessToken := fmt.Sprintf("%v", session.Values["access_token"])

	// Get user profile from Microsoft Graph
	profile, err := getUserProfile(accessToken)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get profile: %v", err), http.StatusInternalServerError)
		return
	}

	renderTemplate(w, "templates/profile.html", profile)
}

func (app *App) filesHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	if session.Values["authenticated"] != true {
		http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
		return
	}

	accessToken := fmt.Sprintf("%v", session.Values["access_token"])

	// Get files from OneDrive
	files, err := getOneDriveFiles(accessToken)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get files: %v", err), http.StatusInternalServerError)
		return
	}

	renderTemplate(w, "templates/files.html", files)
}

func (app *App) logoutHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	session.Values["authenticated"] = false
	session.Values["access_token"] = ""
	session.Values["username"] = ""
	session.Save(r, w)

	http.Redirect(w, r, "/", http.StatusTemporaryRedirect)
}

func getUserProfile(accessToken string) (map[string]interface{}, error) {
	req, err := http.NewRequest("GET", "https://graph.microsoft.com/v1.0/me", nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("Accept", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := ioutil.ReadAll(resp.Body)
		return nil, fmt.Errorf("API request failed with status %d: %s", resp.StatusCode, string(body))
	}

	var profile map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&profile); err != nil {
		return nil, err
	}

	return profile, nil
}

func getOneDriveFiles(accessToken string) (map[string]interface{}, error) {
	req, err := http.NewRequest("GET", "https://graph.microsoft.com/v1.0/me/drive/root/children", nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("Accept", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := ioutil.ReadAll(resp.Body)
		return nil, fmt.Errorf("API request failed with status %d: %s", resp.StatusCode, string(body))
	}

	var files map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&files); err != nil {
		return nil, err
	}

	return files, nil
}

func renderTemplate(w http.ResponseWriter, templatePath string, data interface{}) {
	tmpl, err := ioutil.ReadFile(templatePath)
	if err != nil {
		http.Error(w, fmt.Sprintf("Template not found: %v", err), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/html")
	w.Write(tmpl)
}

func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	b := make([]byte, length)
	for i := range b {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(charset))))
		if err != nil {
			return ""
		}
		b[i] = charset[num.Int64()]
	}
	return string(b)
}
