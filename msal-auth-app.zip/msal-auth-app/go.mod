module msal-auth-app

go 1.21

require (
	github.com/AzureAD/microsoft-authentication-library-for-go v1.2.1
	github.com/gorilla/mux v1.8.1
	github.com/gorilla/sessions v1.2.2
)
