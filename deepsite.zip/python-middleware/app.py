from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import os
from typing import Optional, List
from anthropic import Anthropic
import json

app = FastAPI(title="v0-workspace Claude Middleware", version="1.0.0")

# CORS middleware to allow requests from the Next.js app
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    model: str = "claude-3-5-sonnet-20241022"
    max_tokens: Optional[int] = 4000
    temperature: Optional[float] = 0.7
    stream: Optional[bool] = False

class ChatResponse(BaseModel):
    content: str
    model: str

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "v0-workspace-claude-middleware"}

@app.post("/chat", response_model=ChatResponse)
async def chat_completion(request: ChatRequest):
    """
    Send a chat completion request to Claude API using Anthropic SDK
    """
    print("1. Starting chat completion")
    claude_api_key = os.getenv("CLAUDE_API_KEY")
    if not claude_api_key:
        raise HTTPException(status_code=500, detail="Claude API key not configured")
    
    print("2. Claude API key found")
    
    try:
        print("3. Creating Anthropic client")
        client = Anthropic(api_key=claude_api_key)
        
        print("4. Converting messages format")
        # Convert messages to Anthropic format - handle system prompt properly
        system_prompt = None
        messages = []
        
        for msg in request.messages:
            if msg.role == "system":
                system_prompt = msg.content
            else:
                messages.append({
                    "role": msg.role,
                    "content": msg.content
                })
        
        print("5. Making request to Claude API")
        # Use system parameter for system prompt
        if system_prompt:
            response = client.messages.create(
                model=request.model,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                system=system_prompt,
                messages=messages
            )
        else:
            response = client.messages.create(
                model=request.model,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                messages=messages
            )
        
        print("6. Response received")
        content = response.content[0].text if response.content else ""
        
        print("7. Returning response")
        return ChatResponse(
            content=content,
            model=request.model
        )
        
    except Exception as e:
        print(f"Error: {str(e)}")
        print(f"Error type: {type(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.post("/chat/stream")
async def chat_completion_stream(request: ChatRequest):
    """
    Send a streaming chat completion request to Claude API using Anthropic SDK
    """
    print("1. Starting streaming chat completion")
    claude_api_key = os.getenv("CLAUDE_API_KEY")
    if not claude_api_key:
        print("Error: Claude API key not found")
        raise HTTPException(status_code=500, detail="Claude API key not configured")
    
    print("2. Claude API key found")
    
    async def generate():
        try:
            print("3. Creating Anthropic client")
            client = Anthropic(api_key=claude_api_key)
            
            print("4. Converting messages format")
            # Convert messages to Anthropic format - handle system prompt properly
            system_prompt = None
            messages = []
            
            for msg in request.messages:
                if msg.role == "system":
                    system_prompt = msg.content
                else:
                    messages.append({
                        "role": msg.role,
                        "content": msg.content
                    })
            
            print("5. Making streaming request to Claude API")
            # Use system parameter for system prompt
            if system_prompt:
                stream = client.messages.create(
                    model=request.model,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    system=system_prompt,
                    messages=messages,
                    stream=True
                )
            else:
                stream = client.messages.create(
                    model=request.model,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    messages=messages,
                    stream=True
                )
            
            print("6. Processing stream chunks")
            for chunk in stream:
                if chunk.type == "content_block_delta" and chunk.delta.text:
                    print(f"Yielding chunk: {chunk.delta.text[:50]}...")
                    yield chunk.delta.text
                    
        except Exception as e:
            print(f"Streaming error: {str(e)}")
            print(f"Error type: {type(e)}")
            import traceback
            print(f"Traceback: {traceback.format_exc()}")
            yield f"Error: {str(e)}"
    
    return StreamingResponse(
        generate(), 
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": "*",
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 