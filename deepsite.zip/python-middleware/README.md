# v0-workspace Claude Middleware

A Python FastAPI service that acts as a middleware between the v0-workspace frontend and Claude API.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables:
```bash
export CLAUDE_API_KEY="your-claude-api-key-here"
```

3. Run the service:
```bash
python app.py
```

The service will run on `http://localhost:8000`

## API Endpoints

### Health Check
- `GET /health` - Check if the service is running

### Chat Completion
- `POST /chat` - Send a chat completion request to Claude
- `POST /chat/stream` - Send a streaming chat completion request to Claude

## Environment Variables

- `CLAUDE_API_KEY` - Your Claude API key from Anthropic

## Usage

The middleware handles Claude API calls and provides a simplified interface for the v0-workspace frontend. It includes:

- CORS support for local development
- Error handling for API failures
- Streaming support for real-time responses
- Proper authentication with Claude API 