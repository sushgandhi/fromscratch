/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import { useCookie } from "react-use";

import { User } from "@/types";

export const useUser = () => {
  // For local POC, return null user since we removed authentication
  const user: User | null = null;
  const [currentRoute, setCurrentRoute] = useCookie("v0-workspace-currentRoute");

  const openLoginWindow = () => {
    // No-op for local POC
    console.log("Login disabled in local POC");
  };

  const logout = () => {
    // No-op for local POC
    console.log("Logout disabled in local POC");
  };

  return {
    user,
    openLoginWindow,
    logout,
    currentRoute,
    setCurrentRoute,
  };
};
