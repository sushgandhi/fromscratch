# v0-workspace Local POC

A simplified version of v0-workspace for local proof-of-concept testing without authentication, database, or HuggingFace dependencies.

## Features

- **No Authentication Required**: Start using immediately without login
- **No Database**: Everything resets on page refresh (perfect for POC)
- **Claude AI Integration**: Uses Claude API via Python middleware
- **Local Development**: Run everything locally for testing

## Quick Start

### 1. Setup Environment

```bash
# Copy environment template
cp env.example .env.local

# Edit .env.local and add your Claude API key
# Get your API key from: https://console.anthropic.com/
```

### 2. Install Dependencies

```bash
# Install Node.js dependencies
npm install

# Install Python dependencies
cd python-middleware
pip install -r requirements.txt
cd ..
```

### 3. Start Services

```bash
# Terminal 1: Start Python middleware
cd python-middleware
python app.py
# Middleware will run on http://localhost:8000

# Terminal 2: Start Next.js app
npm run dev
# App will run on http://localhost:3000
```

### 4. Use v0-workspace

1. Open http://localhost:3000 in your browser
2. Start creating websites with AI prompts
3. No login required - just start building!

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Next.js App   │───▶│ Python Middleware│───▶│  Claude API     │
│  (localhost:3000)│    │  (localhost:8000) │    │  (Anthropic)    │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## API Endpoints

### Python Middleware (localhost:8000)

- `GET /health` - Health check
- `POST /chat` - Chat completion
- `POST /chat/stream` - Streaming chat completion

### Next.js App (localhost:3000)

- `POST /api/ask-ai` - Main AI endpoint for website generation
- `PUT /api/ask-ai` - Follow-up edits

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `CLAUDE_API_KEY` | Your Claude API key from Anthropic | Yes |
| `NEXT_PUBLIC_MIDDLEWARE_URL` | URL of Python middleware | No (defaults to localhost:8000) |

## Development

### Adding New Features

1. **Frontend Changes**: Edit files in `app/` and `components/`
2. **API Changes**: Edit files in `app/api/`
3. **AI Service Changes**: Edit `python-middleware/app.py`

### Testing

- Frontend: http://localhost:3000
- Middleware Health: http://localhost:8000/health
- API Documentation: http://localhost:8000/docs (FastAPI auto-generated)

## Troubleshooting

### Common Issues

1. **"Claude API key not configured"**
   - Make sure you've set `CLAUDE_API_KEY` in `.env.local`

2. **"Connection refused" to middleware**
   - Ensure Python middleware is running on port 8000
   - Check if port 8000 is available

3. **"Module not found" errors**
   - Run `npm install` for Node.js dependencies
   - Run `pip install -r requirements.txt` in python-middleware directory

### Logs

- Next.js logs: Check terminal running `npm run dev`
- Python middleware logs: Check terminal running `python app.py`

## Limitations

This is a POC version with the following limitations:

- No user authentication
- No data persistence (everything resets on refresh)
- No project saving/loading
- No deployment to external services
- Limited error handling

## Production Considerations

For production use, consider adding:

- User authentication and authorization
- Database for project persistence
- Rate limiting and usage tracking
- Error monitoring and logging
- Security headers and CORS configuration
- Environment-specific configurations 