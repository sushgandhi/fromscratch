export const PROVIDERS = {
  claude: {
    name: "Claude",
    max_tokens: 4000,
    id: "claude",
  },
  gemini: {
    name: "Gemini",
    max_tokens: 4000,
    id: "gemini",
  },
};

export const MODELS = [
  {
    value: "claude-3-5-sonnet-20241022",
    label: "Claude 3.5 Sonnet",
    providers: ["claude"],
    autoProvider: "claude",
    isThinker: false,
    isNew: false,
  },
  {
    value: "claude-3-opus-20240229",
    label: "Claude 3 Opus",
    providers: ["claude"],
    autoProvider: "claude",
    isThinker: false,
    isNew: false,
  },
  {
    value: "claude-3-sonnet-20240229",
    label: "Claude 3 Sonnet",
    providers: ["claude"],
    autoProvider: "claude",
    isThinker: false,
    isNew: false,
  },
  {
    value: "gemini-1.5-pro",
    label: "Gemini 1.5 Pro",
    providers: ["gemini"],
    autoProvider: "gemini",
    isThinker: false,
    isNew: false,
  },
  {
    value: "gemini-1.5-flash",
    label: "Gemini 1.5 Flash",
    providers: ["gemini"],
    autoProvider: "gemini",
    isThinker: false,
    isNew: true,
  },
];
