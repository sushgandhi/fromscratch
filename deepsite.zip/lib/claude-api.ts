import axios from 'axios';

const MIDDLEWARE_URL = process.env.NEXT_PUBLIC_MIDDLEWARE_URL || 'http://localhost:8000';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatRequest {
  messages: ChatMessage[];
  model?: string;
  max_tokens?: number;
  temperature?: number;
  stream?: boolean;
}

export interface ChatResponse {
  content: string;
  model: string;
}

export const claudeAPI = {
  async chatCompletion(request: ChatRequest): Promise<ChatResponse> {
    try {
      const response = await axios.post(`${MIDDLEWARE_URL}/chat`, request);
      return response.data;
    } catch (error: any) {
      console.error('Claude API Error:', error);
      throw new Error(error.response?.data?.detail || 'Failed to get response from Claude');
    }
  },

  async chatCompletionStream(
    request: ChatRequest,
    onChunk: (chunk: string) => void,
    onComplete: () => void,
    onError: (error: string) => void
  ): Promise<void> {
    try {
      const response = await fetch(`${MIDDLEWARE_URL}/chat/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('Failed to get response reader');
      }

      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        if (chunk) {
          onChunk(chunk);
        }
      }

      onComplete();
    } catch (error: any) {
      console.error('Claude Streaming API Error:', error);
      onError(error.message || 'Failed to stream response from Claude');
    }
  }
}; 