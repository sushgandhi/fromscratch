export const defaultHTML = `<!DOCTYPE html>
<html>
  <head>
    <title>v0-workspace Project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8">
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body class="flex justify-center items-center h-screen overflow-hidden bg-white font-sans text-center px-6">
    <div class="w-full">
      <span class="text-xs rounded-full mb-2 inline-block px-2 py-1 border border-blue-500/15 bg-blue-500/15 text-blue-500">⚡ v0-workspace</span>
      <h1 class="text-4xl lg:text-6xl font-bold font-sans">
        <span class="text-2xl lg:text-4xl text-gray-400 block font-medium">Ready to build,</span>
        What shall we create?
      </h1>
    </div>
    <script></script>
  </body>
</html>
`;
