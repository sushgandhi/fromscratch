export const getCookieName = () => {
  return "v0-workspace-auth-token";
};
