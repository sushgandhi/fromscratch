/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import { toast } from "sonner";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { MdSave } from "react-icons/md";
import { Rocket } from "lucide-react";

import SpaceIcon from "@/assets/space.svg";
import Loading from "@/components/loading";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Input } from "@/components/ui/input";

export function DeployButton({
  html,
  prompts,
}: {
  html: string;
  prompts: string[];
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const [config, setConfig] = useState({
    title: "",
  });

  const createSpace = async () => {
    if (!config.title) {
      toast.error("Please enter a title for your space.");
      return;
    }
    setLoading(true);

    try {
      // For local POC, just show a success message
      toast.success("Project created successfully! (Local POC - no deployment)");
      setLoading(false);
    } catch (err: any) {
      toast.error(err.message || "Failed to create space");
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="default"
            className="max-lg:hidden !px-4 relative"
            disabled={loading}
          >
            <Rocket className="size-4" />
            Deploy your Project{" "}
            {loading && <Loading className="ml-2 size-4 animate-spin" />}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80">
          <div className="grid gap-4">
            <div className="space-y-2">
              <h4 className="font-medium leading-none">Deploy to Local POC</h4>
              <p className="text-sm text-muted-foreground">
                This is a local POC - no actual deployment will occur.
              </p>
            </div>
            <div className="grid gap-2">
              <Input
                placeholder="Project title"
                value={config.title}
                onChange={(e) =>
                  setConfig({ ...config, title: e.target.value })
                }
              />
              <Button onClick={createSpace} disabled={loading}>
                {loading ? (
                  <>
                    <Loading className="mr-2 size-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Rocket className="mr-2 size-4" />
                    Create Project
                  </>
                )}
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
      <Button
        variant="default"
        size="sm"
        className="lg:hidden relative"
        disabled={loading}
      >
        Deploy {loading && <Loading className="ml-2 size-4 animate-spin" />}
      </Button>
    </div>
  );
}
