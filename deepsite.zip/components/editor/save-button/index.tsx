/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import { toast } from "sonner";
import { MdSave } from "react-icons/md";

import Loading from "@/components/loading";
import { Button } from "@/components/ui/button";

export function SaveButton({
  html,
  prompts,
}: {
  html: string;
  prompts: string[];
}) {
  const [loading, setLoading] = useState(false);

  const updateSpace = async () => {
    setLoading(true);

    try {
      // For local POC, just show a success message
      toast.success("Project saved successfully! (Local POC - no persistence)");
    } catch (err: any) {
      toast.error(err.message || "Failed to save project");
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <>
      <Button
        variant="default"
        className="max-lg:hidden !px-4 relative"
        onClick={updateSpace}
      >
        <MdSave className="size-4" />
        Save your Project{" "}
        {loading && <Loading className="ml-2 size-4 animate-spin" />}
      </Button>
      <Button
        variant="default"
        size="sm"
        className="lg:hidden relative"
        onClick={updateSpace}
      >
        Save {loading && <Loading className="ml-2 size-4 animate-spin" />}
      </Button>
    </>
  );
}
