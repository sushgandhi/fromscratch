import { useState } from "react";
import { Link } from "lucide-react";
import { useCopyToClipboard } from "react-use";
import { FaXTwitter } from "react-icons/fa6";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export function InviteFriends() {
  const [, copyToClipboard] = useCopyToClipboard();
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <form>
        <DialogTrigger asChild>
          <Button
            size="iconXs"
            variant="outline"
            className="!border-neutral-600 !text-neutral-400 !hover:!border-neutral-500 hover:!text-neutral-300"
          >
            <Link className="size-4" />
          </Button>
        </DialogTrigger>
        <DialogContent className="!rounded-2xl p-0 !w-full max-w-[400px] !bg-white !border-neutral-100 text-center overflow-hidden">
          <header className="bg-neutral-50 p-6 border-b border-neutral-200/60">
            <div className="flex items-center justify-center -space-x-4 mb-3">
              <div className="size-9 rounded-full bg-pink-200 shadow-2xs flex items-center justify-center text-xl opacity-50">
                💌
              </div>
              <div className="size-11 rounded-full bg-amber-200 shadow-2xl flex items-center justify-center text-2xl z-2">
                🎉
              </div>
              <div className="size-9 rounded-full bg-sky-200 shadow-2xs flex items-center justify-center text-xl opacity-50">
                🚀
              </div>
            </div>
            <p className="text-xl font-semibold text-neutral-950">
              Share v0-workspace!
            </p>
            <p className="text-sm text-neutral-500 mt-1.5">
              Help others discover this AI-powered web development tool.
            </p>
          </header>
          <main className="space-y-4 p-6">
            <div className="mt-4 space-x-3.5">
              <Button
                variant="lightGray"
                size="sm"
                className="!text-neutral-700"
                onClick={() => {
                  copyToClipboard(window.location.origin);
                  toast.success("Link copied to clipboard!");
                }}
              >
                <Link className="size-4" />
                Copy Link
              </Button>
            </div>
          </main>
        </DialogContent>
      </form>
    </Dialog>
  );
}
