import { redirect } from "next/navigation";

export default async function ProjectsPage() {
  // For POC, redirect to the main editor
  redirect("/projects/new");
}
