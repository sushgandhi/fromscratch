/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Metadata, Viewport } from "next";
import { Inter, PT_Sans } from "next/font/google";

import TanstackProvider from "@/components/providers/tanstack-query-provider";
import "@/assets/globals.css";
import { Toaster } from "@/components/ui/sonner";
import AppContext from "@/components/contexts/app-context";
import Script from "next/script";

const inter = Inter({
  variable: "--font-inter-sans",
  subsets: ["latin"],
});

const ptSans = PT_Sans({
  variable: "--font-ptSans-mono",
  subsets: ["latin"],
  weight: ["400", "700"],
});

export const metadata: Metadata = {
  title: "v0-workspace | Build with AI ✨",
  description:
    "v0-workspace is a web development tool that helps you build websites with AI, no code required. Let's deploy your website with v0-workspace and enjoy the magic of AI.",
  openGraph: {
    title: "v0-workspace | Build with AI ✨",
    description:
      "v0-workspace is a web development tool that helps you build websites with AI, no code required. Let's deploy your website with v0-workspace and enjoy the magic of AI.",
    url: "http://localhost:3000",
    siteName: "v0-workspace",
    images: [
      {
        url: "http://localhost:3000/banner.png",
        width: 1200,
        height: 630,
        alt: "v0-workspace Open Graph Image",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "v0-workspace | Build with AI ✨",
    description:
      "v0-workspace is a web development tool that helps you build websites with AI, no code required. Let's deploy your website with v0-workspace and enjoy the magic of AI.",
    images: ["http://localhost:3000/banner.png"],
  },
  appleWebApp: {
    capable: true,
    title: "v0-workspace",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/logo.svg",
    shortcut: "/logo.svg",
    apple: "/logo.svg",
  },
};

export const viewport: Viewport = {
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#000000",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <Script
        defer
        data-domain="localhost:3000"
        src="https://plausible.io/js/script.js"
      ></Script>
      <body
        className={`${inter.variable} ${ptSans.variable} antialiased bg-black dark h-[100dvh] overflow-hidden`}
      >
        <Toaster richColors position="bottom-center" />
        <TanstackProvider>
          <AppContext me={{ user: null, errCode: null }}>{children}</AppContext>
        </TanstackProvider>
      </body>
    </html>
  );
}
