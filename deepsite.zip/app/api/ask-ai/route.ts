/* eslint-disable @typescript-eslint/no-explicit-any */
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

import { MODELS, PROVIDERS } from "@/lib/providers";
import {
  FOLLOW_UP_SYSTEM_PROMPT,
  INITIAL_SYSTEM_PROMPT,
} from "@/lib/prompts";
import { claudeAPI } from "@/lib/claude-api";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { prompt, provider, model, redesignMarkdown, html } = body;

  if (!model || (!prompt && !redesignMarkdown)) {
    return NextResponse.json(
      { ok: false, error: "Missing required fields" },
      { status: 400 }
    );
  }

  const selectedModel = MODELS.find(
    (m) => m.value === model || m.label === model
  );
  if (!selectedModel) {
    return NextResponse.json(
      { ok: false, error: "Invalid model selected" },
      { status: 400 }
    );
  }

  if (!selectedModel.providers.includes(provider) && provider !== "auto") {
    return NextResponse.json(
      {
        ok: false,
        error: `The selected model does not support the ${provider} provider.`,
        openSelectProvider: true,
      },
      { status: 400 }
    );
  }

  const DEFAULT_PROVIDER = PROVIDERS.claude;
  const selectedProvider =
    provider === "auto"
      ? PROVIDERS[selectedModel.autoProvider as keyof typeof PROVIDERS]
      : PROVIDERS[provider as keyof typeof PROVIDERS] ?? DEFAULT_PROVIDER;

  try {
    // Create a stream response
    const encoder = new TextEncoder();
    const stream = new TransformStream();
    const writer = stream.writable.getWriter();

    // Start the response
    const response = new NextResponse(stream.readable, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });

    (async () => {
      let completeResponse = "";
      let writerClosed = false;
      
      const closeWriter = async () => {
        if (!writerClosed) {
          try {
            await writer.close();
            writerClosed = true;
          } catch (error) {
            // Ignore errors if writer is already closed
          }
        }
      };
      
      try {
        const messages = [
          {
            role: "system" as const,
            content: INITIAL_SYSTEM_PROMPT,
          },
          {
            role: "user" as const,
            content: redesignMarkdown
              ? `Here is my current design as a markdown:\n\n${redesignMarkdown}\n\nNow, please create a new design based on this markdown.`
              : html
              ? `Here is my current HTML code:\n\n\`\`\`html\n${html}\n\`\`\`\n\nNow, please create a new design based on this HTML.`
              : prompt,
          },
        ];

        await claudeAPI.chatCompletionStream(
          {
            messages,
            model: selectedModel.value,
            max_tokens: selectedProvider.max_tokens,
            temperature: 0.7,
            stream: true,
          },
          (chunk) => {
            // Write chunk to stream
            if (!writerClosed) {
              try {
                writer.write(encoder.encode(chunk));
                completeResponse += chunk;
              } catch (error) {
                // Ignore write errors if stream is closed
              }
            }
          },
          async () => {
            // Stream complete
            await closeWriter();
          },
          async (error) => {
            // Handle error
            if (!writerClosed) {
              try {
                writer.write(
                  encoder.encode(
                    JSON.stringify({
                      ok: false,
                      message: error,
                    })
                  )
                );
              } catch (writeError) {
                // Ignore write errors
              }
            }
            await closeWriter();
          }
        );
      } catch (error: any) {
        if (!writerClosed) {
          try {
            await writer.write(
              encoder.encode(
                JSON.stringify({
                  ok: false,
                  message:
                    error.message ||
                    "An error occurred while processing your request.",
                })
              )
            );
          } catch (writeError) {
            // Ignore write errors
          }
        }
        await closeWriter();
      }
    })();

    return response;
  } catch (error: any) {
    return NextResponse.json(
      {
        ok: false,
        openSelectProvider: true,
        message:
          error?.message || "An error occurred while processing your request.",
      },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  const body = await request.json();
  const { prompt, html, previousPrompt, provider, selectedElementHtml } = body;

  if (!prompt || !html) {
    return NextResponse.json(
      { ok: false, error: "Missing required fields" },
      { status: 400 }
    );
  }

  const selectedModel = MODELS[0];
  const DEFAULT_PROVIDER = PROVIDERS.claude;
  const selectedProvider =
    provider === "auto"
      ? PROVIDERS[selectedModel.autoProvider as keyof typeof PROVIDERS]
      : PROVIDERS[provider as keyof typeof PROVIDERS] ?? DEFAULT_PROVIDER;

  try {
    const messages = [
      {
        role: "system" as const,
        content: FOLLOW_UP_SYSTEM_PROMPT,
      },
      {
        role: "user" as const,
        content: previousPrompt
          ? previousPrompt
          : "You are modifying the HTML file based on the user's request.",
      },
      {
        role: "assistant" as const,
        content: `The current code is: \n\`\`\`html\n${html}\n\`\`\` ${
          selectedElementHtml
            ? `\n\nYou have to update ONLY the following element, NOTHING ELSE: \n\n\`\`\`html\n${selectedElementHtml}\n\`\`\``
            : ""
        }`,
      },
      {
        role: "user" as const,
        content: prompt,
      },
    ];

    const response = await claudeAPI.chatCompletion({
      messages,
      model: selectedModel.value,
      max_tokens: selectedProvider.max_tokens,
      temperature: 0.7,
    });

    const content = response.content;
    if (!content) {
      return NextResponse.json(
        { ok: false, message: "No content returned from the model" },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        ok: true,
        html: content,
        updatedLines: [],
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      {
        ok: false,
        message:
          error?.message || "An error occurred while processing your request.",
      },
      { status: 500 }
    );
  }
}
