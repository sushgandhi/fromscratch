module glean-mcp

go 1.21

require (
	github.com/gleanwork/api-client-go v0.0.0-20240725154012-0b0de4a7b1b9
	github.com/mark3labs/mcp-go v0.10.0
)

require (
	github.com/google/uuid v1.6.0 // indirect
	github.com/joho/godotenv v1.5.1 // indirect
	github.com/tidwall/gjson v1.17.3 // indirect
	github.com/tidwall/match v1.1.1 // indirect
	github.com/tidwall/pretty v1.2.0 // indirect
	golang.org/x/net v0.27.0 // indirect
)
