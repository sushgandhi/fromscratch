package glean

import (
	"context"
	"fmt"
	"os"

	apiclientgo "github.com/gleanwork/api-client-go"
	"github.com/gleanwork/api-client-go/models/components"
)

// Client represents a Glean API client
type Client struct {
	apiClient *apiclientgo.Client
}

// NewClient creates a new Glean client with authentication
func NewClient() (*Client, error) {
	gleanToken := os.Getenv("GLEAN_API_TOKEN")
	gleanInstance := os.Getenv("GLEAN_INSTANCE")

	if gleanToken == "" || gleanInstance == "" {
		return nil, fmt.Errorf("GLEAN_API_TOKEN and GLEAN_INSTANCE environment variables are required")
	}

	client := apiclientgo.New(
		apiclientgo.WithSecurity(gleanToken),
		apiclientgo.WithInstance(gleanInstance),
	)

	return &Client{
		apiClient: client,
	}, nil
}

// SearchRequest represents a search request to Glean
type SearchRequest struct {
	Query      string
	PageSize   int64
	Types      []string
	Department string
}

// SearchResult represents a single search result
type SearchResult struct {
	Title       string `json:"title"`
	URL         string `json:"url"`
	Snippet     string `json:"snippet"`
	Type        string `json:"type"`
	Author      string `json:"author"`
	LastUpdated string `json:"lastUpdated"`
}

// Search performs a search in Glean
func (c *Client) Search(ctx context.Context, req SearchRequest) ([]SearchResult, error) {
	searchRequest := components.SearchRequest{
		Query:    req.Query,
		PageSize: &req.PageSize,
	}

	// Add type filters if provided
	if len(req.Types) > 0 {
		var typeValues []components.FacetFilterValue
		for _, t := range req.Types {
			typeValues = append(typeValues, components.FacetFilterValue{
				Value:        &t,
				RelationType: components.RelationTypeEquals.ToPointer(),
			})
		}
		if searchRequest.RequestOptions == nil {
			searchRequest.RequestOptions = &components.SearchRequestOptions{}
		}
		searchRequest.RequestOptions.FacetFilters = append(searchRequest.RequestOptions.FacetFilters, components.FacetFilter{
			FieldName: &[]string{"type"}[0],
			Values:    typeValues,
		})
	}

	// Add department filter if provided
	if req.Department != "" {
		if searchRequest.RequestOptions == nil {
			searchRequest.RequestOptions = &components.SearchRequestOptions{}
		}
		searchRequest.RequestOptions.FacetFilters = append(searchRequest.RequestOptions.FacetFilters, components.FacetFilter{
			FieldName: &[]string{"department"}[0],
			Values: []components.FacetFilterValue{
				{
					Value:        &req.Department,
					RelationType: components.RelationTypeEquals.ToPointer(),
				},
			},
		})
	}

	// Execute search
	res, err := c.apiClient.Client.Search.Query(ctx, searchRequest)
	if err != nil {
		return nil, fmt.Errorf("failed to search Glean: %w", err)
	}

	// Format results
	var results []SearchResult
	if res.SearchResponse != nil && res.SearchResponse.Results != nil {
		for _, result := range res.SearchResponse.Results {
			item := SearchResult{
				Title:       result.Title,
				URL:         result.URL,
				Snippet:     result.Snippet,
				Type:        result.Type,
				Author:      result.Author,
				LastUpdated: result.LastActivityAt,
			}
			results = append(results, item)
		}
	}

	return results, nil
}
