package main

import (
	"context"
	"fmt"
	"log"

	"glean-mcp/pkg/glean"

	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

func main() {
	// Create MCP server
	s := server.NewMCPServer(
		"Glean Search MCP Server",
		"1.0.0",
		server.WithCapabilities(map[string]interface{}{
			"tools": true,
		}),
	)

	// Add Glean search tool
	s.AddTool(mcp.Tool{
		Name:        "glean_search",
		Description: "Search Glean for documents and content",
		InputSchema: mcp.ToolInputSchema{
			Type: "object",
			Properties: map[string]interface{}{
				"query": map[string]interface{}{
					"type":        "string",
					"description": "Search query to find relevant documents",
				},
				"page_size": map[string]interface{}{
					"type":        "integer",
					"description": "Number of results to return (default: 10)",
					"default":     10,
				},
				"types": map[string]interface{}{
					"type":        "array",
					"items":       map[string]string{"type": "string"},
					"description": "Filter by document types (e.g., article, document)",
				},
				"department": map[string]interface{}{
					"type":        "string",
					"description": "Filter by department (e.g., engineering)",
				},
			},
			Required: []string{"query"},
		},
	}, handleGleanSearch)

	// Start the server
	if err := s.ServeStdio(); err != nil {
		log.Fatalf("Server error: %v", err)
	}
}

func handleGleanSearch(ctx context.Context, params map[string]interface{}) (*mcp.CallToolResult, error) {
	// Get parameters
	query, ok := params["query"].(string)
	if !ok || query == "" {
		return nil, fmt.Errorf("query parameter is required")
	}

	pageSize := int64(10)
	if ps, ok := params["page_size"].(float64); ok {
		pageSize = int64(ps)
	}

	// Initialize Glean client
	client, err := glean.NewClient()
	if err != nil {
		return nil, fmt.Errorf("failed to initialize Glean client: %w", err)
	}

	// Build search request
	var types []string
	if typesParam, ok := params["types"].([]interface{}); ok {
		for _, t := range typesParam {
			if typeStr, ok := t.(string); ok {
				types = append(types, typeStr)
			}
		}
	}

	department := ""
	if dept, ok := params["department"].(string); ok {
		department = dept
	}

	// Perform search
	searchReq := glean.SearchRequest{
		Query:      query,
		PageSize:   pageSize,
		Types:      types,
		Department: department,
	}

	results, err := client.Search(ctx, searchReq)
	if err != nil {
		return nil, fmt.Errorf("failed to search Glean: %w", err)
	}

	// Format results
	var formattedResults []map[string]interface{}
	for _, result := range results {
		item := map[string]interface{}{
			"title":       result.Title,
			"url":         result.URL,
			"snippet":     result.Snippet,
			"type":        result.Type,
			"author":      result.Author,
			"lastUpdated": result.LastUpdated,
		}
		formattedResults = append(formattedResults, item)
	}

	return &mcp.CallToolResult{
		Content: []interface{}{
			map[string]interface{}{
				"type": "text",
				"text": fmt.Sprintf("Found %d results for query: %s", len(formattedResults), query),
			},
			map[string]interface{}{
				"type": "object",
				"object": map[string]interface{}{
					"results": formattedResults,
				},
			},
		},
	}, nil
}
