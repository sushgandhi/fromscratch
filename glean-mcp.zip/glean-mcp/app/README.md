# Glean MCP Server

A Model Context Protocol (MCP) server implementation in Go that provides search capabilities for Glean.

## Overview

This MCP server exposes a single tool `glean_search` that allows searching Glean for documents and content with various filtering options.

## Features

- Search Glean for documents and content
- Filter by document types (article, document, etc.)
- Filter by department
- Configurable page size
- Secure API token handling

## Prerequisites

- Go 1.21 or higher
- Docker (for containerization)
- Helm 3.x (for Kubernetes deployment)
- OpenShift CLI (for OpenShift deployment)

## Local Development

### Setup

1. Clone the repository
2. Set environment variables:
   ```bash
   export GLEAN_API_TOKEN=your_glean_api_token
   export GLEAN_INSTANCE=your_glean_instance
   ```

3. Install dependencies:
   ```bash
   go mod download
   ```

4. Run the server:
   ```bash
   go run main.go
   ```

### Building

```bash
# Build binary
go build -o glean-mcp .

# Build Docker image
docker build -t glean-mcp:latest .
```

## MCP Tool Usage

The server exposes a single tool called `glean_search` with the following parameters:

- `query` (required): Search query string
- `page_size` (optional): Number of results to return (default: 10)
- `types` (optional): Array of document types to filter by
- `department` (optional): Department to filter by

### Example Usage

```json
{
  "tool": "glean_search",
  "arguments": {
    "query": "vacation policy",
    "page_size": 5,
    "types": ["article", "document"],
    "department": "engineering"
  }
}
```

## Kubernetes Deployment

### Using Helm

1. Update values in `helm/values.yaml`:
   - Set your Glean API token
   - Set your Glean instance URL
   - Configure image repository

2. Install the chart:
   ```bash
   helm install glean-mcp ./helm \
     --set secrets.glean-api-token=your_token \
     --set configMap.glean-instance=your_instance
   ```

3. For OpenShift:
   ```bash
   oc new-project glean-mcp
   helm install glean-mcp ./helm \
     --set secrets.glean-api-token=your_token \
     --set configMap.glean-instance=your_instance \
     --set route.enabled=true \
     --set route.host=glean-mcp.apps.your-cluster.com
   ```

### Manual Deployment

1. Create secrets:
   ```bash
   kubectl create secret generic glean-mcp-secrets \
     --from-literal=glean-api-token=your_token
   ```

2. Create configmap:
   ```bash
   kubectl create configmap glean-mcp-config \
     --from-literal=glean-instance=your_instance
   ```

3. Deploy:
   ```bash
   kubectl apply -f helm/templates/
   ```

## Environment Variables

- `GLEAN_API_TOKEN`: Your Glean API token
- `GLEAN_INSTANCE`: Your Glean instance URL

## Security

- Runs as non-root user (UID 1001)
- Uses read-only root filesystem
- Drops all capabilities
- Uses secrets for sensitive data

## Health Checks

- Liveness probe: `/health`
- Readiness probe: `/ready`

## License

MIT
